Install packages for standard platforms
